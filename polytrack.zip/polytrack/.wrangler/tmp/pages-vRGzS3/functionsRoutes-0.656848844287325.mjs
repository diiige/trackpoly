import { onRequestDelete as __api_v6_leaderboard_js_onRequestDelete } from "/home/runner/workspace/polytrack/functions/api/v6/leaderboard.js"
import { onRequestGet as __api_v6_leaderboard_js_onRequestGet } from "/home/runner/workspace/polytrack/functions/api/v6/leaderboard.js"
import { onRequestPost as __api_v6_leaderboard_js_onRequestPost } from "/home/runner/workspace/polytrack/functions/api/v6/leaderboard.js"
import { onRequestPost as __api_v6_leaderboardNickname_js_onRequestPost } from "/home/runner/workspace/polytrack/functions/api/v6/leaderboardNickname.js"
import { onRequestGet as __api_v6_leaderboardUserEntry_js_onRequestGet } from "/home/runner/workspace/polytrack/functions/api/v6/leaderboardUserEntry.js"
import { onRequestGet as __api_v6_trackOfTheWeek_js_onRequestGet } from "/home/runner/workspace/polytrack/functions/api/v6/trackOfTheWeek.js"

export const routes = [
    {
      routePath: "/api/v6/leaderboard",
      mountPath: "/api/v6",
      method: "DELETE",
      middlewares: [],
      modules: [__api_v6_leaderboard_js_onRequestDelete],
    },
  {
      routePath: "/api/v6/leaderboard",
      mountPath: "/api/v6",
      method: "GET",
      middlewares: [],
      modules: [__api_v6_leaderboard_js_onRequestGet],
    },
  {
      routePath: "/api/v6/leaderboard",
      mountPath: "/api/v6",
      method: "POST",
      middlewares: [],
      modules: [__api_v6_leaderboard_js_onRequestPost],
    },
  {
      routePath: "/api/v6/leaderboardNickname",
      mountPath: "/api/v6",
      method: "POST",
      middlewares: [],
      modules: [__api_v6_leaderboardNickname_js_onRequestPost],
    },
  {
      routePath: "/api/v6/leaderboardUserEntry",
      mountPath: "/api/v6",
      method: "GET",
      middlewares: [],
      modules: [__api_v6_leaderboardUserEntry_js_onRequestGet],
    },
  {
      routePath: "/api/v6/trackOfTheWeek",
      mountPath: "/api/v6",
      method: "GET",
      middlewares: [],
      modules: [__api_v6_trackOfTheWeek_js_onRequestGet],
    },
  ]